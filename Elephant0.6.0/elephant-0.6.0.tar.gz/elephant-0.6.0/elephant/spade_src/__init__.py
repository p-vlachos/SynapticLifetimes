# -*- coding: utf-8 -*-
from . import fast_fca
