var DOCUMENTATION_OPTIONS = {
    URL_ROOT: '',
    VERSION: '0.4.1',
    LANGUAGE: 'en',
    COLLAPSE_INDEX: false,
    FILE_SUFFIX: '.html',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt'
};