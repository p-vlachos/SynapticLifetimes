=======================
Spike train correlation
=======================

.. testsetup::

   from quantities import Hz, s, ms
   from elephant.spike_train_correlation import corrcoef


.. automodule:: elephant.spike_train_correlation
   :members:
   :exclude-members: cch, sttc
