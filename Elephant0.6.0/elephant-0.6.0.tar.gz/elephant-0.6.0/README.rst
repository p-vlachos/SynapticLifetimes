Elephant - Electrophysiology Analysis Toolkit
=============================================

Elephant is a package for the analysis of neurophysiology data, based on Neo.

Code status
-----------

.. image:: https://travis-ci.org/NeuralEnsemble/elephant.png?branch=master
   :target: https://travis-ci.org/NeuralEnsemble/elephant
   :alt: Unit Test Status
.. image:: https://coveralls.io/repos/NeuralEnsemble/elephant/badge.png
   :target: https://coveralls.io/r/NeuralEnsemble/elephant
   :alt: Unit Test Coverage
.. image:: https://requires.io/github/NeuralEnsemble/elephant/requirements.png?branch=master
   :target: https://requires.io/github/NeuralEnsemble/elephant/requirements/?branch=master
   :alt: Requirements Status
.. image:: https://readthedocs.org/projects/elephant/badge/?version=latest
   :target: https://readthedocs.org/projects/elephant/?badge=latest
   :alt: Documentation Status

:copyright: Copyright 2014-2018 by the Elephant team, see AUTHORS.txt.
:license: Modified BSD License, see LICENSE.txt for details.
